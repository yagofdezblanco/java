package ejercicio1;

public class ejercicio1 {
    public static void main(String str[]){
        Concesionario conce=new Concesionario();
        Coche c1=new Coche(552525, 32000, 145, 312, 105, "Audi", "a3");
        Coche c2=new Coche(552528, 75000, 200, 340, 105, "Audi", "a5");
        Coche c3=new Coche(552522, 125000, 350, 312, 85, "Audi", "TT");
        Coche c4=new Coche(552521, 15000, 110, 312, 105, "Wolkswagen", "Vento");
        Coche c5=new Coche(552523, 35000, 120, 312, 105, "Wolkswagen", "Passat");
        Coche c6=new Coche(552524, 16000, 95, 312, 105, "Toyota", "auris");
        Coche c7=new Coche(552526, 9000, 85, 312, 105, "Ford", "fiesta");
        Coche c8=new Coche(552529, 17000, 140, 312, 105, "Ford", "mondeo");
        Coche c9=new Coche(552552, 18600, 150, 312, 105, "Chevrolet", "tabeo");
        Coche c10=new Coche(552545, 18000, 135, 312, 105, "Citroen", "c6");
        
        conce.incluirCoche(c1);
        conce.incluirCoche(c2);
        conce.incluirCoche(c3);
        conce.incluirCoche(c4);
        conce.incluirCoche(c5);
        conce.incluirCoche(c6);
        conce.incluirCoche(c7);
        conce.incluirCoche(c8);
        conce.incluirCoche(c9);
        conce.incluirCoche(c10);
        
        System.out.println("LISTADO DE COCHES POR NUMERO DE BASTIDOR");
        conce.listar();
        System.out.println("\nLISTADO DE COCHES POR MARCA");
        conce.listar(new ComparadorMarca());
        System.out.println("\nLISTADO DE COCHES POR PRECIO");
        conce.listar(new ComparadorPrecio());
        System.out.println("\nLISTADO DE COCHES POR CILINDRADA");
        conce.listar(new ComparadorCilindrada());
    }
}
