package ejercicio2;

public class ejercicio2 {
    
}
