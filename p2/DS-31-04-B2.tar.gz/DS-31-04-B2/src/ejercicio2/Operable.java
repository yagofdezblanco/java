package ejercicio2;

public interface Operable <T>{
    T suma(T obj);
    T resta(T obj);
    T multiplicacion(T obj);
    T division(T obj);
}